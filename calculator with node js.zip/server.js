const http = require('http');
const { requestHandler } = require('./handler');  // import handler.js

const server = http.createServer(requestHandler);

server.listen(5000, () => {
    console.log("Server running at http://localhost:3000");
});